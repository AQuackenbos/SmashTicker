# [Super Smash Bros. Stream Lister](http://example.com/#) v0.1.0
Grabs streams off twitch for Super Smash Bros.  Concept/models built off of Dota 2 Match Ticker.

## API

## Download

## License
MIT
